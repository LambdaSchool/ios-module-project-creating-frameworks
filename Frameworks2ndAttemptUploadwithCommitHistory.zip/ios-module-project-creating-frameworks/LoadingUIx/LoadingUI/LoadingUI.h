//
//  LoadingUI.h
//  LoadingUI
//
//  Created by Lambda_School_Loaner_268 on 3/25/20.
//  Copyright © 2020 Lambda. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LoadingUI.
FOUNDATION_EXPORT double LoadingUIVersionNumber;

//! Project version string for LoadingUI.
FOUNDATION_EXPORT const unsigned char LoadingUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoadingUI/PublicHeader.h>


